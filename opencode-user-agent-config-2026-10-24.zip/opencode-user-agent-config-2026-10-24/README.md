# OpenCode user-level agent configuration snapshot

This archive is a portable snapshot of the validated, active OpenCode agent configuration as of 2026-10-24.

## Included

- `opencode/`: the selected configuration from `~/.config/opencode`, including `AGENTS.md`, `opencode.jsonc`, agents, commands, plugins, templates, the plugin validator, and its Node package manifests.
- `opencode/skills/`: the runtime skill mirror auto-loaded by OpenCode.
- `opencode/skill-sets/`: the authoritative skill-set source used for validation and release work. It intentionally differs from the runtime mirror in provenance and test-only material.
- `global-skills/`: the target of the active `~/.opencode/skills` symlink.
- `ARCHIVE-MANIFEST.sha256`: SHA-256 for every archived payload file, generated immediately before ZIP creation.

## Deliberately excluded

No credentials, session history, databases, logs, cache, browser artifacts, dependency directories, or Python bytecode are included. In particular, `~/.local/share/opencode/auth.json` is not part of this export.

The pre-package credential scan found no credential value. Three reviewed pattern-only matches are retained as code/documentation: two Markdown anchor fragments and one synthetic redaction-test fixture. They are not user secrets, credentials, or authentication material.

## Restore

Extract the archive, then copy `opencode/` to `~/.config/opencode/` and `global-skills/` to `~/.shared-skills/`. Recreate the active global-skill alias with `ln -sfn ~/.shared-skills ~/.opencode/skills`. Preserve any existing credentials and session data separately.

## Validation recorded before packaging

1. `bash opencode/skill-sets/project-artifact-excellence-set/validation/validate-set.sh` passed all eight gates in the live canonical source.
2. `bash opencode/excellence-ops/validate-plugins.sh` passed all runtime gates, including 25 Node tests and 60 routing probes.
3. `opencode debug config` loaded the required `fullstack-delivery` agent, `fullstack-deliver` command, and `excellence-ops` plugin.

Use the checksum manifest and `unzip -t` to verify transfer integrity after download.
