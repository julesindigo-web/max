// excellence-ops.js — user-level opencode plugin pack (masterpiece v2.1.1).
//
// Three focused plugins complement the project-artifact-excellence-set:
//   SecretsGuardPlugin        — tool.execute.before: fail-closed secrets + destructive-command guard.
//   ExcellenceValidatePlugin  — tool.execute.after:  auto-validate edited skills / set contracts.
//   ExcellenceTelemetryPlugin — event (session.idle/command.executed/session.error) + experimental.session.compacting.
//
// Design rules: deterministic, offline, dependency-free (node builtins only),
// never mutate user data except the telemetry JSONL log, never throw except
// to block a guarded action. Kill-switch: EXCELLENCE_AUTOVALIDATE=0 disables
// validator execution (reminders are still appended).
//
// v2.1.1 exports only plugin factories from plugins/; pure test helpers live
// in excellence-ops/lib so the runtime never attempts to load a helper as a hook.
// v2.0.0 changes over v1.0.0:
//   - SecretsGuard now checks directory-scoped `path` in addition to `filePath`
//     for read/grep/glob/list (grep/glob scope searches via `path`; verified
//     against 1.18 tool titles `Grep "<pattern>"`/`Glob "<pattern>"` with
//     `t.input.path`). Pattern strings are never blocked (regex false positives).
//   - ExcellenceValidate reads edit args from `input.args` first (1.18 runtime
//     shape for tool.execute.after) with `output.args` fallback (legacy mocks),
//     and warns (never blocks) when `apply_patch` deletes SKILL.md/manifest.yaml/SET.md.
//   - ExcellenceTelemetry uses the documented `event` hook
//     (`event: async ({event}) => …`, see plugins docs Send-notifications example)
//     for session.idle/command.executed/session.error with redacted fields only
//     (ids, command names, error kinds — never message bodies, arguments, or
//     secrets). Legacy `session.idle`/`command.executed` keys are kept as
//     deprecated aliases; `session.error` alias is added.
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import {
  GUARDED_READ_TOOLS,
  appendTelemetry,
  extractApplyPatchDeletes,
  findSetRoot,
  isDestructiveCommand,
  isSetCompositionPath,
  redactedErrorKind,
  secretPathFromArgs,
  verdictForEdit,
} from "../excellence-ops/lib/excellence-ops-helpers.js";

// ---------------------------------------------------------------------------
// Plugin 1: SecretsGuard — fail closed on secret reads and destructive shell.
// ---------------------------------------------------------------------------
export const SecretsGuardPlugin = async () => {
  return {
    "tool.execute.before": async (input, output) => {
      const args = output.args || {};
      if (GUARDED_READ_TOOLS.has(input.tool)) {
        const hit = secretPathFromArgs(args);
        if (hit !== null) {
          throw new Error(
            `SecretsGuard: refusing to read secret-adjacent path '${hit}'. ` +
              `Redact or reference it indirectly instead.`
          );
        }
      }
      if (input.tool === "bash" && typeof args.command === "string") {
        if (isDestructiveCommand(args.command)) {
          throw new Error(
            `SecretsGuard: refusing destructive shell command. Re-run scoped to an explicit safe path.`
          );
        }
      }
    },
  };
};

// ---------------------------------------------------------------------------
// Plugin 2: ExcellenceValidate — validate edited skills and set contracts.
// ---------------------------------------------------------------------------
function runValidator(cmd, args, cwd, timeoutMs) {
  try {
    const out = execFileSync(cmd, args, { cwd, timeout: timeoutMs, encoding: "utf-8", stdio: ["ignore", "pipe", "pipe"] });
    return { ok: true, tail: String(out).trim().split("\n").slice(-4).join("\n") };
  } catch (err) {
    const tail = [err.stdout, err.stderr].filter(Boolean).join("\n").trim().split("\n").slice(-8).join("\n");
    return { ok: false, tail: tail || String(err.message).split("\n")[0] };
  }
}

export const ExcellenceValidatePlugin = async () => {
  return {
    "tool.execute.after": async (input, output) => {
      // Delete-guard: apply_patch carries paths inside patchText (documented
      // `*** Delete File:` markers), not filePath. Warn and guide, never block.
      // There is no documented `file.deleted` event in 1.18 (verified: plugin
      // Hooks .d.ts event list + SDK Event union have file.edited and
      // file.watcher.updated only), so patch markers are the delete signal.
      if (input.tool === "apply_patch") {
        const patchText = (input.args && input.args.patchText) ?? (output.args && output.args.patchText);
        const deletes = extractApplyPatchDeletes(patchText);
        const hits = deletes.filter(isSetCompositionPath);
        if (hits.length > 0) {
          output.output = `${output.output}\n\n[excellence-ops] WARNING: apply_patch deletes set-composition file(s): ${hits.join(", ")}. Deletion breaks set composition (SKILL.md/manifest.yaml/SET.md). Restore the file or confirm intent, then run the full set gate manually.`;
        }
        return;
      }
      if (input.tool !== "write" && input.tool !== "edit") return;
      // 1.18 runtime delivers after-hook args on `input.args`; legacy mocks
      // and older shims use `output.args`. Prefer input, fall back to output.
      const edited = (input.args && input.args.filePath) ?? (output.args && output.args.filePath);
      if (typeof edited !== "string") return;
      const setRoot = findSetRoot(path.dirname(path.resolve(edited)));
      if (!setRoot) return;
      const verdict = verdictForEdit(setRoot, edited);
      if (verdict.kind === "none") return;
      const enabled = process.env.EXCELLENCE_AUTOVALIDATE !== "0";
      const single = path.join(setRoot, "skills-create-excellence", "scripts", "validate-excellence.sh");
      if (!enabled) {
        output.output = `${output.output}\n\n[excellence-ops] EXCELLENCE_AUTOVALIDATE=0: skipped auto-validation for '${edited}'. Run the gate manually.`;
        return;
      }
      if (verdict.kind === "skill" && fs.existsSync(single)) {
        const res = runValidator("bash", [single, verdict.memberDir], setRoot, 120000);
        output.output = `${output.output}\n\n[excellence-ops] single-skill gate ${res.ok ? "PASS" : "FAIL"} for '${verdict.memberDir}':\n${res.tail}`;
        return;
      }
      const res = runValidator("bash", [path.join("validation", "validate-set.sh")], setRoot, 300000);
      output.output = `${output.output}\n\n[excellence-ops] full set gate (8 gates) ${res.ok ? "PASS" : "FAIL"}:\n${res.tail}`;
    },
  };
};

// ---------------------------------------------------------------------------
// Plugin 3: ExcellenceTelemetry — evidence trail + compaction context.
// ---------------------------------------------------------------------------
const COMPACTION_CONTEXT = `## Excellence continuity (auto-injected)
Preserve across compaction: current task and status, files being modified, open Critical/Major findings with evidence states, next validation step. Calibration law holds: missing evidence is Unknown/Untested, never a pass; severity is never raised on missing evidence alone.`;

// Shared redacted handler for Event-bus records. Logs ids, command names,
// and error kinds only — never message bodies, command arguments, or secrets.
async function handleTelemetryEvent(ev) {
  if (!ev || typeof ev.type !== "string") return;
  if (ev.type === "session.idle") {
    appendTelemetry({ event: "session.idle", sessionID: ev.properties && ev.properties.sessionID });
  } else if (ev.type === "command.executed") {
    appendTelemetry({
      event: "command.executed",
      sessionID: ev.properties && ev.properties.sessionID,
      command: ev.properties && ev.properties.name,
    });
  } else if (ev.type === "session.error") {
    appendTelemetry({
      event: "session.error",
      sessionID: ev.properties && ev.properties.sessionID,
      errorKind: redactedErrorKind(ev.properties && ev.properties.error),
    });
  }
}

export const ExcellenceTelemetryPlugin = async () => {
  return {
    // Documented Event-bus entry point (see plugins docs Send-notifications
    // example: `event: async ({event}) => { if (event.type === …) … }`).
    // This is the runtime-correct path; the `session.*`/`command.*` keys
    // below are deprecated aliases kept for backward compatibility.
    event: async (input) => {
      try {
        await handleTelemetryEvent(input && input.event);
      } catch {
        // telemetry must never break a session
      }
    },
    // Deprecated aliases (v1 hook-key style). Retained so existing mocks and
    // any shim dispatching by event-type key keep working; new code should
    // rely on `event` above.
    "session.idle": async (input) => {
      try {
        appendTelemetry({ event: "session.idle", sessionID: input.sessionID });
      } catch {
        // telemetry must never break a session
      }
    },
    "command.executed": async (input) => {
      try {
        appendTelemetry({ event: "command.executed", sessionID: input.sessionID, command: input.command ?? input.name });
      } catch {
        // telemetry must never break a session
      }
    },
    "session.error": async (input) => {
      try {
        const err = (input && (input.error ?? (input.properties && input.properties.error))) ?? null;
        appendTelemetry({
          event: "session.error",
          sessionID: input.sessionID ?? (input.properties && input.properties.sessionID),
          errorKind: redactedErrorKind(err),
        });
      } catch {
        // telemetry must never break a session
      }
    },
    "experimental.session.compacting": async (_input, output) => {
      output.context.push(COMPACTION_CONTEXT);
    },
  };
};
